// Sokoyetu — règles métier exécutées sur le serveur (chargé avec require dans chaque hook).
const OPS = { mpesa: 'M-Pesa', airtel: 'Airtel Money', orange: 'Orange Money', illico: 'Illico Cash' };
const DEFAULT_ZONES = [{ id: 'bukavu', name: 'Bukavu', fee: 2, days: 1 }, { id: 'goma', name: 'Goma', fee: 5, days: 2 }, { id: 'retrait', name: 'Retrait en boutique', fee: 0, days: 0 }];
const round = (v) => Math.round((Number(v) || 0) * 100) / 100;
const digits = (s) => String(s || '').replace(/\D/g, '');
const clean = (s, max) => String(s || '').replace(/[\u0000-\u0008\u000B-\u001F\u007F]/g, '').replace(/[ \t]+/g, ' ').trim().slice(0, max);
function parse(rec, field) {
  try { const s = rec.getString(field || 'doc'); const v = s ? JSON.parse(s) : {}; return v && typeof v === 'object' ? v : {}; } catch (e) { return {}; }
}
function normPhone(s) {
  const raw = String(s || '').trim(); let d = digits(raw);
  if (d.startsWith('00')) d = d.slice(2);
  if (d.startsWith('243') && d.length === 12) d = '0' + d.slice(3);
  if (/^0[89]\d{8}$/.test(d)) return d;
  if (/^\+/.test(raw) && d.length >= 10 && d.length <= 15) return '+' + d;
  return '';
}
function config(app) {
  let c = {};
  try { c = parse(app.findRecordById('config', 'store')); } catch (e) { }
  if (!Array.isArray(c.zones) || !c.zones.length) c.zones = DEFAULT_ZONES;
  if (!c.payments) c.payments = {};
  if (!c.cod) c.cod = { enabled: true };
  return c;
}
function checkDiscount(app, codeIn, subtotal) {
  const code = String(codeIn || '').trim().toUpperCase();
  if (!/^[A-Z0-9-]{3,20}$/.test(code)) return { ok: false, reason: 'Ce code n’est pas valide.' };
  let rec; try { rec = app.findFirstRecordByData('discounts', 'code', code); } catch (e) { return { ok: false, reason: 'Ce code n’est pas valide.' }; }
  const d = parse(rec);
  if (d.active === false || (d.endsAt && d.endsAt < Date.now())) return { ok: false, reason: 'Ce code n’est pas valide.' };
  const min = Number(d.minSubtotal) || 0; const sub = round(subtotal);
  if (min && sub < min) return { ok: false, reason: `Ce code s’applique dès $${min.toFixed(2)} d’achat.`, minSubtotal: min };
  const v = Number(d.value) || 0; if (v <= 0) return { ok: false, reason: 'Ce code n’est pas valide.' };
  const amount = round(d.type === 'percent' ? sub * Math.min(v, 90) / 100 : Math.min(v, sub));
  return { ok: true, code, type: d.type === 'percent' ? 'percent' : 'fixed', value: v, amount };
}
/* Rebuilds a customer's order from the catalogue: prices, stock, discount, delivery fee and total come from the server, never from the browser. */
function prepareOrder(app, rec) {
  const fail = (m) => { throw new BadRequestError(m); };
  const d = parse(rec); const cfg = config(app);
  const token = String(rec.getString('token') || '');
  if (!/^[A-Za-z0-9]{24,64}$/.test(token)) fail('Jeton de commande invalide. Actualisez la page.');
  if (!d.termsAcceptedAt) fail('Les conditions de vente doivent être acceptées.');
  const name = clean(d.customer && d.customer.name, 60); if (name.length < 2) fail('Nom invalide.');
  const phone = normPhone(d.customer && d.customer.phone); if (!phone) fail('Numéro de téléphone invalide.');
  const zone = cfg.zones.find((z) => z.id === (d.shipping && d.shipping.zoneId)); if (!zone) fail('Zone de livraison inconnue.');
  const pickup = !Number(zone.fee) && !Number(zone.days);
  const address = clean(d.shipping && d.shipping.address, 120); if (!pickup && address.length < 4) fail('Adresse de livraison manquante.');
  const lines = Array.isArray(d.items) ? d.items.slice(0, 50) : []; if (!lines.length) fail('Votre panier est vide.');
  let sub = 0; const items = [];
  for (const it of lines) {
    let p = null; try { p = app.findRecordById('products', String(it.productId || '')); } catch (e) { fail('Un article n’est plus disponible. Actualisez votre panier.'); }
    const pd = parse(p);
    if (!p.getBool('active') || pd.status === 'draft') fail(`« ${pd.title || 'Article'} » n’est plus disponible.`);
    const qty = Math.floor(Number(it.qty)); if (!(qty >= 1 && qty <= 20)) fail('Quantité invalide.');
    const colors = ((pd.options && pd.options.colors) || []).map((c) => c.name), sizes = (pd.options && pd.options.sizes) || [];
    const color = colors.length ? String(it.color || '') : '', size = sizes.length ? String(it.size || '') : '';
    if (colors.length && colors.indexOf(color) < 0) fail(`Couleur indisponible pour « ${pd.title} ».`);
    if (sizes.length && sizes.indexOf(size) < 0) fail(`Taille indisponible pour « ${pd.title} ».`);
    if (pd.source !== 'import') {
      const st = (colors.length || sizes.length) ? Math.floor(Number((pd.variants || {})[`${color}|${size}`] || 0)) : Math.floor(Number(pd.stock || 0));
      if (st < qty) fail(`Stock insuffisant pour « ${pd.title} » : ${Math.max(0, st)} disponible${st > 1 ? 's' : ''}.`);
    }
    const price = round(pd.price); if (!(price > 0)) fail(`Prix indisponible pour « ${pd.title} ».`);
    sub += price * qty;
    const img = (pd.images || []).find((m) => m && m.type !== 'data') || null;
    items.push({ productId: p.id, title: pd.title, color, size, qty, price, cost: round(pd.cost), source: pd.source || 'local', image: img });
  }
  sub = round(sub);
  let discount = null;
  if (d.discount && d.discount.code) { const r = checkDiscount(app, d.discount.code, sub); if (!r.ok) fail(r.reason); discount = { code: r.code, amount: r.amount }; }
  let ship = round(zone.fee); const fso = Number(cfg.freeShippingOver) || 0;
  if (fso > 0 && sub - (discount ? discount.amount : 0) >= fso) ship = 0;
  const total = round(Math.max(0, sub - (discount ? discount.amount : 0) + ship));
  // Le client a vu (et souvent déjà payé) un montant : s'il ne correspond plus, on refuse plutôt que d'enregistrer un autre total
  if (d.total === undefined || Math.abs(Number(d.total) - total) > 0.009) fail(`Les prix ou la livraison ont changé : le nouveau total est de $${total.toFixed(2)}. Vérifiez votre commande avant de confirmer.`);
  const m = String((d.payment && d.payment.method) || ''); let payment;
  if (m === 'cod') {
    if (!cfg.cod || !cfg.cod.enabled) fail('Le paiement à la livraison n’est pas proposé.');
    payment = { method: 'cod', label: 'Paiement à la livraison', ref: '', sender: '', status: 'pending' };
  } else {
    const pc = cfg.payments[m];
    if (!OPS[m] || !pc || !pc.enabled || !digits(pc.number)) fail('Ce mode de paiement n’est pas disponible.');
    const ref = String((d.payment && d.payment.ref) || '').trim().toUpperCase().replace(/\s+/g, '');
    if (!/^[A-Z0-9][A-Z0-9.\-_/]{3,29}$/.test(ref)) fail('Code de transaction invalide.');
    payment = { method: m, label: OPS[m], ref, sender: normPhone(d.payment && d.payment.sender) || phone, status: 'pending' };
  }
  const now = Date.now();
  const out = {
    number: $security.randomStringWithAlphabet(5, 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'), createdAt: now, termsAcceptedAt: now, phone: digits(phone),
    customer: { name, phone }, shipping: { zoneId: zone.id, zoneName: zone.name, address: pickup ? '' : address, landmark: clean(d.shipping && d.shipping.landmark, 80) },
    note: clean(d.note, 300), items, subtotal: sub, discount, shippingFee: ship, total, payment,
    fulfillment: 'unfulfilled', status: 'open', timeline: [{ at: now, text: 'Commande passée par le client' }]
  };
  rec.set('doc', out); rec.set('phone', digits(phone)); rec.set('status', 'open');
}
function isStaff(info) {
  try { return !!info && (info.hasSuperuserAuth() || (!!info.auth && info.auth.collection().name === 'admins')); } catch (e) { return false; }
}
module.exports = { isStaff, parse, normPhone, checkDiscount, prepareOrder, config };
