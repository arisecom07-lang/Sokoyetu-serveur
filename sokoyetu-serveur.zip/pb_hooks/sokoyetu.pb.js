/// <reference path="../pb_data/types.d.ts" />
// Sokoyetu — hooks serveur.

// Commande client : reconstruite par le serveur à partir du catalogue (prix, stock, remise, livraison, total).
onRecordCreateRequest((e) => {
  // Toujours, y compris si la gérante est connectée sur le même téléphone (seul le tableau technique /_/ y échappe)
  if (!e.hasSuperuserAuth()) require(`${__hooks}/sokoyetu_lib.js`).prepareOrder(e.app, e.record);
  return e.next();
}, 'orders');

// Champs techniques tenus à jour automatiquement (visibilité des produits, code promo indexé)
onRecordCreateRequest((e) => { const L = require(`${__hooks}/sokoyetu_lib.js`); const d = L.parse(e.record); e.record.set('active', d.status !== 'draft'); return e.next(); }, 'products');
onRecordUpdateRequest((e) => { const L = require(`${__hooks}/sokoyetu_lib.js`); const d = L.parse(e.record); e.record.set('active', d.status !== 'draft'); return e.next(); }, 'products');
onRecordCreateRequest((e) => { const L = require(`${__hooks}/sokoyetu_lib.js`); const d = L.parse(e.record); e.record.set('code', String(d.code || '').trim().toUpperCase()); return e.next(); }, 'discounts');
onRecordUpdateRequest((e) => { const L = require(`${__hooks}/sokoyetu_lib.js`); const d = L.parse(e.record); e.record.set('code', String(d.code || '').trim().toUpperCase()); return e.next(); }, 'discounts');

// Vérification d'un code promo sans exposer la liste des codes
routerAdd('GET', '/api/sokoyetu/discount', (e) => {
  const L = require(`${__hooks}/sokoyetu_lib.js`);
  const q = e.requestInfo().query || {};
  const r = L.checkDiscount(e.app, q['code'], Number(q['subtotal'] || 0));
  return e.json(200, r.ok ? { ok: true, code: r.code, type: r.type, value: r.value, amount: r.amount } : { ok: false, reason: r.reason });
});

// Ce que les clients ne voient jamais : note interne et coûts d'achat (marges)
onRecordEnrich((e) => {
  const L = require(`${__hooks}/sokoyetu_lib.js`);
  if (!L.isStaff(e.requestInfo)) { const d = L.parse(e.record); delete d.adminNote; (d.items || []).forEach((i) => { delete i.cost; }); e.record.set('doc', d); }
  return e.next();
}, 'orders');
onRecordEnrich((e) => {
  const L = require(`${__hooks}/sokoyetu_lib.js`);
  if (!L.isStaff(e.requestInfo)) { const d = L.parse(e.record); delete d.cost; e.record.set('doc', d); }
  return e.next();
}, 'products');

// Console : créer le compte administrateur ou changer son mot de passe
//   ./pocketbase sokoyetu-admin e-mail mot-de-passe
$app.rootCmd.addCommand(new Command({
  use: 'sokoyetu-admin',
  short: 'Crée ou met à jour le compte administrateur de la boutique',
  run: (cmd, args) => {
    const email = String(args[0] || '').trim().toLowerCase(), pass = String(args[1] || '');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || pass.length < 10) { console.error('Usage : sokoyetu-admin e-mail mot-de-passe (10 caractères minimum)'); $os.exit(1); }
    let rec;
    try { rec = $app.findAuthRecordByEmail('admins', email); } catch (e) { rec = new Record($app.findCollectionByNameOrId('admins')); rec.setEmail(email); }
    rec.setPassword(pass); rec.setVerified(true);
    $app.save(rec);
    console.log('Compte administrateur prêt : ' + email);
  }
}));

// www.sokoyakwetu.com → sokoyakwetu.com (une seule adresse pour le référencement)
routerUse((e) => {
  const h = String(e.request.host || '');
  if (h.indexOf('www.') === 0) return e.redirect(301, 'https://' + h.slice(4) + e.request.url.requestURI());
  return e.next();
});
