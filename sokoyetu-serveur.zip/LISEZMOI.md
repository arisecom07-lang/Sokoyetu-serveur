# Sokoyetu — paquet serveur

Tout ce qu’il faut pour faire tourner la boutique et l’administration sur un serveur Ubuntu (Droplet DigitalOcean), à l’adresse https://sokoyakwetu.com.

| Élément | Rôle |
|---|---|
| installer.sh | Installation complète : PocketBase 0.40.5 (empreinte vérifiée), pare-feu, service automatique, certificat HTTPS, compte administrateur |
| mise-a-jour.sh | Remplace le site et les règles serveur par une nouvelle version ; sauvegarde la base avant ; garde produits, commandes, photos |
| mot-de-passe.sh | Nouveau mot de passe administrateur (mot de passe oublié) |
| android.sh | Relie l’application Google Play au site (fichier assetlinks.json) |
| pb_public/ | Le site : boutique (index.html) et administration (admin.html) |
| pb_migrations/ | Structure de la base, règles d’accès, limites anti-spam, sauvegarde quotidienne |
| pb_hooks/ | Règles métier côté serveur : recalcul des prix et du total de chaque commande, contrôle du stock, codes promo, masquage des coûts d’achat |

## Installation (résumé)
1. Déposer `sokoyetu-serveur.zip` dans un dépôt GitHub public (par exemple `sokoyetu-serveur`).
2. Créer un Droplet Ubuntu 24.04 et coller, dans « Additional Options » → « Startup scripts » (user data) :

```bash
#!/bin/bash
exec > /var/log/sokoyetu-installation.log 2>&1
set -e
export EMAIL="votre-email@exemple.com"
export MOT_DE_PASSE="Lettres-Chiffres-Tirets-2026"   # 10 caractères minimum, sans guillemet ni $
export PAQUET="https://github.com/VOTRE-COMPTE/sokoyetu-serveur/raw/main/sokoyetu-serveur.zip"
curl -fsSL "$PAQUET" -o /root/sokoyetu.zip
python3 -m zipfile -e /root/sokoyetu.zip /root/sokoyetu
bash /root/sokoyetu/installer.sh
```

3. Chez le fournisseur du nom de domaine : enregistrements A `@` et `www` vers l’adresse IP du Droplet.
4. Ouvrir https://sokoyakwetu.com/admin.html et se connecter. Changer ensuite le mot de passe dans Plus → Compte.

## Commandes utiles (console du Droplet)
- Mettre à jour : `sudo /opt/sokoyetu/mise-a-jour.sh`
- Mot de passe oublié : `sudo /opt/sokoyetu/mot-de-passe.sh vous@exemple.com 'NouveauMotDePasse'`
- État du service : `systemctl status sokoyetu`
- Journal de l’installation : `cat /var/log/sokoyetu-installation.log`
- Accès au tableau technique (/_/) : `sudo cat /root/sokoyetu-acces.txt`

## Sauvegardes
- Automatique chaque nuit à 3 h (7 dernières gardées) dans `/opt/sokoyetu/pb_data/backups`, téléchargeables depuis le tableau technique.
- Copie avant chaque mise à jour dans `/opt/sokoyetu/sauvegardes`.
- Recommandé en plus : activer les sauvegardes DigitalOcean du Droplet (copie hors du serveur).
