#!/bin/bash
# Sokoyetu — mise à jour de la boutique (vos produits, commandes et photos sont conservés)
#   sudo /opt/sokoyetu/mise-a-jour.sh                 (reprend l'adresse du paquet utilisée à l'installation)
#   sudo /opt/sokoyetu/mise-a-jour.sh https://.../sokoyetu-serveur.zip
set -euo pipefail
DIR=/opt/sokoyetu
[ "$(id -u)" = 0 ] || { echo "Lancez ce script avec sudo."; exit 1; }
PAQUET="${1:-$(cat "$DIR/.paquet" 2>/dev/null || true)}"
[ -n "$PAQUET" ] || { echo "Indiquez l'adresse du fichier sokoyetu-serveur.zip."; exit 1; }
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
curl -fsSL -H 'Cache-Control: no-cache' -o "$T/s.zip" "$PAQUET?t=$(date +%s)"
python3 -m zipfile -e "$T/s.zip" "$T/s"
[ -d "$T/s/pb_public" ] && [ -d "$T/s/pb_hooks" ] || { echo "Paquet invalide."; exit 1; }
systemctl stop sokoyetu
echo "==> Sauvegarde de la base avant mise à jour"
mkdir -p "$DIR/sauvegardes"; tar -czf "$DIR/sauvegardes/avant-maj-$(date +%Y%m%d-%H%M).tar.gz" --exclude=pb_data/backups --exclude=pb_data/.autocert_cache -C "$DIR" pb_data
ls -1t "$DIR"/sauvegardes/avant-maj-*.tar.gz | tail -n +4 | xargs -r rm -f
for d in pb_hooks pb_migrations; do rm -rf "$DIR/$d"; cp -r "$T/s/$d" "$DIR/$d"; done
[ -d "$DIR/pb_public/.well-known" ] && mv "$DIR/pb_public/.well-known" "$T/wk"
rm -rf "$DIR/pb_public"; cp -r "$T/s/pb_public" "$DIR/pb_public"
[ -d "$T/wk" ] && mv "$T/wk" "$DIR/pb_public/.well-known"
for f in mise-a-jour.sh mot-de-passe.sh android.sh; do [ -f "$T/s/$f" ] && cp "$T/s/$f" "$DIR/$f" && chmod 700 "$DIR/$f"; done
echo "$PAQUET" > "$DIR/.paquet"
chown -R sokoyetu:sokoyetu "$DIR"
sudo -u sokoyetu "$DIR/pocketbase" migrate up --dir="$DIR/pb_data" --hooksDir="$DIR/pb_hooks" --migrationsDir="$DIR/pb_migrations"
systemctl start sokoyetu; sleep 3
systemctl is-active --quiet sokoyetu && echo "==> Mise à jour terminée." || { journalctl -u sokoyetu -n 30 --no-pager; exit 1; }
