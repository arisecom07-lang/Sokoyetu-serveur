/* Sokoyetu — offline support for the installed app. Version 20261024000823 */
const VERSION = 'sokoyetu-20261024000823', FONTS = 'sokoyetu-fonts', IMG = 'sokoyetu-img';
const SHELL = ['./', './index.html', './offline.html', './site.webmanifest', './favicon.svg', './icon-192.png', './icon-512.png', './icon-maskable-512.png', './apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL))); });
self.addEventListener('activate', e => { e.waitUntil((async () => { for (const k of await caches.keys()) if (k.startsWith('sokoyetu-') && ![VERSION, FONTS, IMG].includes(k)) await caches.delete(k); await self.clients.claim(); })()); });
self.addEventListener('message', e => { if (e.data === 'skipWaiting') self.skipWaiting(); });
async function trim(name, max) { const c = await caches.open(name); const k = await c.keys(); for (let i = 0; i < k.length - max; i++) await c.delete(k[i]); }
self.addEventListener('fetch', e => {
  const r = e.request; if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin === location.origin) {
    if (/\/admin\.html$/.test(u.pathname) || /^\/(_|\.well-known)\//.test(u.pathname)) return;   /* administration : toujours en ligne */
    if (u.pathname.startsWith('/api/') && !u.pathname.startsWith('/api/files/')) return;     /* données du serveur : jamais en cache ici (la boutique garde sa propre copie) */
    if (r.mode === 'navigate') {                                     /* pages : réseau d'abord, copie hors ligne ensuite */
      e.respondWith(fetch(r).then(res => { if (res.ok && /\/(index\.html)?$/.test(u.pathname)) { const cp = res.clone(); caches.open(VERSION).then(c => c.put('./index.html', cp)); } return res; })
        .catch(async () => (await caches.match(r, { ignoreSearch: true })) || (await caches.match('./index.html')) || caches.match('./offline.html')));
      return;
    }
    e.respondWith(caches.match(r).then(hit => hit || fetch(r).then(res => { if (res.ok && r.destination === 'image') { const cp = res.clone(); caches.open(IMG).then(c => c.put(r, cp)).then(() => trim(IMG, 120)); } return res; })));
    return;
  }
  if (u.hostname === 'fonts.googleapis.com' || u.hostname === 'fonts.gstatic.com' || r.destination === 'image') {  /* polices et photos : copie locale, mise à jour en arrière-plan */
    const name = r.destination === 'image' ? IMG : FONTS;
    e.respondWith(caches.open(name).then(async c => { const hit = await c.match(r); const net = fetch(r).then(res => { if (res.ok || res.type === 'opaque') c.put(r, res.clone()); return res; }).catch(() => hit); return hit || net; }));
  }
});
