/* Sokoyetu — fonctionnement hors connexion et mises à jour de l'application installée (boutique). */
const VERSION = 'sokoyetu-2.5.0+202610301717';
const PHOTOS = 'sokoyetu-photos';
const PRECACHE = ["/","/assets/airtel-2J74O2BD.webp","/assets/boutique.caa721f3e3.js","/assets/boutique.e9ce827253.css","/assets/fraunces-5YJQ66G4.woff2","/assets/mpesa-5KY42VCC.webp","/assets/orange-UDTOZWLO.webp","/assets/plus-jakarta-sans-XZSBT77D.woff2","/assets/timbre-KK22OLLX.svg","/favicon.svg","/icone-192.png","/icone-512.png","/icone-masquable-512.png","/index.html","/offline.html","/site.webmanifest"];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(PRECACHE.map((u) => new Request(u, { cache: 'reload' })))));
});
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith('sokoyetu-') && k !== VERSION && k !== PHOTOS) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener('message', (e) => { if (e.data === 'skipWaiting') self.skipWaiting(); });

async function limiter(nom, max) {
  const c = await caches.open(nom); const cles = await c.keys();
  for (let i = 0; i < cles.length - max; i++) await c.delete(cles[i]);
}
const delai = (ms) => new Promise((_, ko) => setTimeout(() => ko(new Error('délai')), ms));

self.addEventListener('fetch', (e) => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin !== location.origin) return;
  if (/^\/(_|\.well-known)\//.test(u.pathname)) return;
  // Vidéos et lectures par morceaux (Range) : laissées au navigateur (une réponse partielle ne se met pas en cache).
  if (r.headers.has('range') || /\.(mp4|webm|mov|m4v)$/i.test(u.pathname)) return;

  // Photos des articles : copie locale d'abord (rapide et disponible hors connexion), 300 au plus.
  if (u.pathname.startsWith('/api/files/') || u.pathname.startsWith('/photos/')) {
    e.respondWith(caches.open(PHOTOS).then(async (c) => {
      const deja = await c.match(r);
      if (deja) return deja;
      const res = await fetch(r);
      if (res.status === 200) c.put(r, res.clone()).then(() => limiter(PHOTOS, 300)).catch(() => { }); // mémoire pleine : tant pis
      return res;
    }));
    return;
  }
  // Données : toujours depuis le serveur (la boutique garde sa propre copie du catalogue).
  if (u.pathname.startsWith('/api/')) return;

  // Pages : le réseau d'abord (3,5 s au plus), puis la dernière version gardée, puis la page « hors connexion ».
  if (r.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const res = await Promise.race([fetch(r), delai(3500)]);
        if (res.ok && u.pathname === '/') { const copie = res.clone(); caches.open(VERSION).then((c) => c.put('/', copie)).catch(() => { }); }
        return res;
      } catch (err) {
        const c = await caches.open(VERSION);
        return (await c.match('/')) || (await c.match('/offline.html')) || Response.error();
      }
    })());
    return;
  }
  // Fichiers de l'application (noms uniques par version) : copie locale d'abord.
  e.respondWith(caches.match(r, { ignoreSearch: u.pathname.startsWith('/assets/') }).then((deja) => deja || fetch(r).then((res) => {
    if (res.status === 200 && (u.pathname.startsWith('/assets/') || /\.(png|svg|webmanifest)$/.test(u.pathname))) { const copie = res.clone(); caches.open(VERSION).then((c) => c.put(r, copie)).catch(() => { }); }
    return res;
  })));
});
