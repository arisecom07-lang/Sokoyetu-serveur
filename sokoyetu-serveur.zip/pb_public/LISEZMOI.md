# Sokoyetu — le site

Ces fichiers sont servis par le serveur Sokoyetu (dossier /opt/sokoyetu/pb_public). Ils sont remplacés à chaque mise à jour.

| Fichier | Rôle |
|---|---|
| index.html | La boutique : https://sokoyakwetu.com/ |
| admin.html | L’administration : https://sokoyakwetu.com/admin.html (connexion par e-mail et mot de passe, non indexée) |
| 404.html | Page « introuvable » |
| robots.txt, sitemap.xml, llms.txt | Référencement et description pour les assistants IA |
| site.webmanifest, icon-*.png, favicon.svg, apple-touch-icon.png, shot-*.webp | Application installable (Android et iPhone) |
| og-image.png | Aperçu lors d’un partage (WhatsApp, Facebook…) |
| sw.js, offline.html | Fonctionnement hors connexion et mises à jour de l’application |
| exemple-catalogue.json | Catalogue d’exemple (Admin → Plus → Général) |
| .well-known/assetlinks.json | À ajouter pour l’application Google Play (voir ANDROID.md) ; conservé lors des mises à jour |

Généré le 2026-10-24.
